//array of my 3 favorite Singers
let favSingers = ["Eraserheads","Taylor Swift","Arthur Nery"];
console.log(favSingers[0]);//log first singer
//array of my 4 favorite Numbers
let favNumbers = [11, 17, 23, 10];
console.log(favNumbers);//log my favNumbers
//array to store different data types
let mixedArr = ["string",["otherArray"], 123, true];
console.log(mixedArr[0]);//log string
console.log(mixedArr[1][0]);//log otherArray
console.log(mixedArr[2]);//log 123
console.log(mixedArr[3]);//log boolean true